import { useEffect, useState } from "react";
import { useParams, Link } from "react-router";
import {
  getCheckinById,
  getAnswersForCheckin,
  getResultRules,
  resolveResultRule,
} from "../lib/engine.js";
import { pb } from "../lib/pb.js";
import ZoneCard from "../components/ZoneCard.jsx";
import ChevronLeft from "icon:chevron-left";
import BarChart2 from "icon:bar-chart-2";
import RefreshCw from "icon:refresh-cw";

export default function Result() {
  const { id } = useParams();
  const [checkin, setCheckin] = useState(null);
  const [rule, setRule] = useState(null);
  const [answersDisplay, setAnswersDisplay] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      try {
        const entry = await getCheckinById(id, controller.signal);

        // Load result rule
        const rules = await getResultRules(entry.method_id, controller.signal);
        const resolved = resolveResultRule(rules, entry.total_score);

        // Load answers with question + option labels
        const answers = await getAnswersForCheckin(id, controller.signal);

        // Fetch question texts and option labels
        const enriched = await Promise.all(
          answers.map(async (a) => {
            try {
              const [q, opt] = await Promise.all([
                pb.collection("questions").getOne(a.question_id, { signal: controller.signal }),
                pb.collection("answer_options").getOne(a.answer_option_id, { signal: controller.signal }),
              ]);
              return { question: q.question_text, answer: opt.label };
            } catch {
              return { question: "–", answer: "–" };
            }
          })
        );

        setCheckin(entry);
        setRule(resolved);
        setAnswersDisplay(enriched);
        setLoading(false);
      } catch (err) {
        if (!err?.isAbort && err?.name !== "AbortError") {
          setError(true);
          setLoading(false);
        }
      }
    }

    load();
    return () => controller.abort();
  }, [id]);

  if (loading) {
    return (
      <main className="max-w-xl mx-auto px-5 pt-20 flex justify-center">
        <p className="text-gray-400">Wird geladen …</p>
      </main>
    );
  }

  if (error || !checkin || !rule) {
    return (
      <main className="max-w-xl mx-auto px-5 pt-20 text-center">
        <p className="text-gray-500 mb-4">Eintrag nicht gefunden.</p>
        <Link to="/" className="text-teal-600 underline">Zur Startseite</Link>
      </main>
    );
  }

  return (
    <main className="max-w-xl mx-auto px-5 pt-6 pb-28 md:pb-10">
      {/* Back */}
      <div className="flex items-center gap-3 mb-6">
        <Link
          to="/history"
          className="w-10 h-10 rounded-xl bg-gray-50 border border-gray-200 flex items-center justify-center hover:bg-gray-100 transition-colors"
        >
          <ChevronLeft size={20} color="#374151" />
        </Link>
        <p className="text-sm font-medium text-gray-500">Dein Ergebnis</p>
      </div>

      <p className="text-xs text-gray-400 mb-4">
        {new Date(checkin.created).toLocaleDateString("de-DE", {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
        })}
        {" · "}
        {new Date(checkin.created).toLocaleTimeString("de-DE", {
          hour: "2-digit",
          minute: "2-digit",
        })} Uhr
      </p>

      {/* Zone card */}
      <div className="mb-8">
        <ZoneCard rule={rule} />
      </div>

      {/* Answers */}
      {answersDisplay.length > 0 && (
        <div className="mb-8">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
            Deine Antworten
          </p>
          <div className="flex flex-col gap-3">
            {answersDisplay.map((a, i) => (
              <div key={i} className="bg-gray-50 rounded-2xl px-5 py-4 border border-gray-100">
                <p className="text-xs text-gray-400 mb-1">{a.question}</p>
                <p className="text-sm font-medium text-gray-700">{a.answer}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex flex-col gap-3">
        <Link
          to="/checkin"
          className="flex items-center justify-center gap-2 w-full rounded-2xl px-5 py-4 border-2 border-gray-200 text-gray-700 font-medium hover:border-gray-300 transition-colors text-sm"
        >
          <RefreshCw size={16} />
          Neuer Check-in
        </Link>
        <Link
          to="/history"
          className="flex items-center justify-center gap-2 w-full rounded-2xl px-5 py-4 text-white font-medium text-sm transition-opacity hover:opacity-90"
          style={{ backgroundColor: "#2a9d8f" }}
        >
          <BarChart2 size={16} />
          Zum Verlauf
        </Link>
      </div>
    </main>
  );
}
