import { useEffect, useState } from 'react';
import { loadModules } from '@/core/modules/moduleRegistry';
import { ModuleNavigation } from '@/shell/components/ModuleNavigation';
import Heart from 'icon:heart';
import Zap from 'icon:zap';
import Lightbulb from 'icon:lightbulb';

export function HomePage() {
  const [modules, setModules] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const allModules = await loadModules();
        const activeModules = allModules.filter(
          m => m.is_enabled && m.module_status === 'active'
        );
        setModules(activeModules);
      } catch (err) {
        console.error('Failed to load modules:', err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <div className="space-y-6">
        <div className="space-y-4">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-nw-heading leading-tight">
            Erkenne Deine Energie
          </h1>
          <p className="text-lg sm:text-xl text-nw-charcoal max-w-2xl leading-relaxed">
            NeuroWays hilft Dir, Deine Energie, Deine Regulation und Deine inneren Ressourcen zu verstehen. Beobachte, lerne und wachse.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 pt-8">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-nw-violet" />
              <span className="text-sm font-bold text-nw-charcoal">Ressourcen</span>
            </div>
            <p className="text-xs text-nw-light-gray">Erkenne Deine Stärken</p>
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-nw-gold" />
              <span className="text-sm font-bold text-nw-charcoal">Energie</span>
            </div>
            <p className="text-xs text-nw-light-gray">Verfolge Dein Level</p>
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-nw-teal" />
              <span className="text-sm font-bold text-nw-charcoal">Regulation</span>
            </div>
            <p className="text-xs text-nw-light-gray">Finde Dein Gleichgewicht</p>
          </div>
        </div>
      </div>

      {/* Module Navigation */}
      <ModuleNavigation orientation="horizontal" />

      {/* Features Section */}
      {!loading && modules.length > 0 && (
        <div className="space-y-8 pt-12 border-t border-nw-section-gray">
          <div>
            <h2 className="text-2xl font-bold text-nw-heading mb-8">Deine Module</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {modules.map(module => (
                <a
                  key={module.id}
                  href={module.base_path}
                  className="group p-6 bg-nw-white border border-nw-section-gray rounded-lg hover:shadow-lg hover:border-nw-teal transition-all duration-fast"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-3 flex-1">
                      <h3 className="font-bold text-nw-heading text-lg group-hover:text-nw-navy transition-colors">
                        {module.name}
                      </h3>
                      {module.description && (
                        <p className="text-sm text-nw-charcoal leading-relaxed">
                          {module.description}
                        </p>
                      )}
                    </div>
                    <span className="text-2xl group-hover:translate-x-1 transition-transform duration-fast">
                      →
                    </span>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
