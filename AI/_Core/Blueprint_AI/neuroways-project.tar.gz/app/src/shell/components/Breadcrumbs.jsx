export function Breadcrumbs({ items = [] }) {
  if (items.length === 0) {
    return null;
  }

  return (
    <nav aria-label="Breadcrumb" className="flex items-center gap-2">
      {items.map((item, index) => (
        <div key={index} className="flex items-center gap-2">
          {index > 0 && (
            <span className="text-nw-section-gray" aria-hidden="true">
              /
            </span>
          )}
          {item.route ? (
            <a
              href={item.route}
              className="text-sm font-bold text-nw-charcoal hover:text-nw-navy transition-colors"
            >
              {item.label}
            </a>
          ) : (
            <span className="text-sm font-bold text-nw-navy">
              {item.label}
            </span>
          )}
        </div>
      ))}
    </nav>
  );
}
