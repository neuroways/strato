import { useState } from 'react';
import { Header } from './Header';
import { Sidebar } from './Sidebar';
import { MobileNavigation } from './MobileNavigation';
import { Breadcrumbs } from './Breadcrumbs';

export function StandardLayout({ children, breadcrumbs = [] }) {
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-nw-soft-white">
      {/* Header */}
      <Header 
        onMobileMenuToggle={() => setIsMobileNavOpen(!isMobileNavOpen)}
        isMobileNavOpen={isMobileNavOpen}
      />

      <div className="flex flex-1 pt-24 md:pt-28">
        {/* Desktop Sidebar */}
        <aside className="hidden md:flex md:w-64 bg-nw-white border-r border-nw-section-gray flex-col">
          <Sidebar />
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col bg-nw-soft-white">
          {/* Breadcrumbs */}
          {breadcrumbs.length > 0 && (
            <div className="border-b border-nw-section-gray bg-nw-white px-4 py-3 md:px-6">
              <Breadcrumbs items={breadcrumbs} />
            </div>
          )}

          {/* Page Content */}
          <div className="flex-1 p-4 md:p-6">
            {children}
          </div>
        </main>
      </div>

      {/* Mobile Navigation */}
      {isMobileNavOpen && (
        <MobileNavigation onClose={() => setIsMobileNavOpen(false)} />
      )}
    </div>
  );
}
