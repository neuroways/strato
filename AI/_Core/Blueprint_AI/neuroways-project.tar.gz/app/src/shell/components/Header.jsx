export function Header({ onMobileMenuToggle, isMobileNavOpen }) {
  return (
    <header className="fixed top-0 left-0 right-0 h-24 md:h-28 bg-nw-white border-b border-nw-section-gray z-40 flex items-center px-4 md:px-6">
      <div className="flex items-center justify-between w-full">
        {/* Logo */}
        <div className="flex items-center gap-0 h-full">
          <img 
            src="/static/neuroways-wordmark.png" 
            alt="NeuroWays" 
            className="h-full w-auto object-contain"
          />
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={onMobileMenuToggle}
          className="md:hidden p-2 rounded-medium hover:bg-nw-pale-blue transition-colors duration-fast"
          aria-label="Toggle navigation"
        >
          <svg
            className="w-6 h-6 text-nw-charcoal"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            {isMobileNavOpen ? (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            ) : (
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            )}
          </svg>
        </button>
      </div>
    </header>
  );
}
